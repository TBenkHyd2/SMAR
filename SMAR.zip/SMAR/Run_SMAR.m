%  %%%%%%%%%%%%%%%%%%%  RAINFALL RUNOFF MODEL %%%%%%%%%%%%%%%%%%%%%%%%%)
% SOIL MOISTURE ACCOUNTING AND ROUTING (SMAR--- SMARG Version)  - BY T. BENKACI & N. DECHEMI 
% Deterministic Optimisation Method: ---Interior Point Method
disp('   SMAR RAINFALL-RUNOFF MODEL')
disp ('   PRESS ENTER')
pause
close all; clc; clear all; %mise � jour de toutes les variables 
global x Nash Qsim Qobs f

data=load('File_Data.txt');  % File data in text File
P = data(:,1);   % First Column Daily Precipitation in mm
E = data(:,2);   % Second Column Daily Evapotranspiration in mm
Qobs=data(:,3);  % Third Column Observed Daily Discharge :Target (in m3/s)
param=load('parameters.txt');

Sup=param(1); % First Parameter of Basin: Area of Basin in Km2


NPAR=9; % Number of Parameters
%SMAR Parameters Lower and Upper Bounds
lb=[ 0.1   0.01    10.     .5      0.1     50.    0.2    1.     0.5]; 
ub=[ 0.99  0.8     400.    .999    0.91   500.     9.0   8.    10.]; 
x0=[ 0.8  0.09    30.    .76     0.6     100.    1.22  2.3   8.0];  % Change initial Parameters for others Basins
% Beacuse of the optimisation method is Deterministic, change Start
% (initial)Points for others basins to obtain optimal Direction of Search.

    [bestx,fval,exitflag,output,lambda]=fmincon(@(x)FSMARG(x,P,E,Qobs,Sup,param),x0,[],[],[],[], lb, ub,[],...
    optimset('Display','iter','MaxIter',600,...
     'MaxFunEvals',500,'TolFun',1E-7,'TolCon',1E-10,...
     'Largescale','off','Algorithm','interior-point'));  
% After optimisation the model displays Simulated data and others Results  

%File of Simulation After optimisation 
SMARG


